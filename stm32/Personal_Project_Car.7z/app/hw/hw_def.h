
#ifndef HW_DEF_H_
#define HW_DEF_H_


#include "def.h"


#endif /* COMMON_DEF_H_ */
