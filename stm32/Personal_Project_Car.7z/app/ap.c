#include "ap.h"
#include "led.h"

// Global variables
uint8_t IN1_Value = 0;
uint8_t IN2_Value = 0;
uint8_t IN3_Value = 0;
uint8_t IN4_Value = 0;

uint8_t rxData[8];
uint8_t receive_data [20];
uint8_t transmite_data [20];


// Initialization of app
void apInit() {
	// Start PWM
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
	HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);
}

// New Main Functions
void apMain() {
	// Declare duty of motor variables.
	uint8_t left_duty = 0, right_duty = 0;

	HAL_UART_Receive_DMA(&huart1, receive_data, sizeof(receive_data));
	HAL_UART_Transmit_DMA(&huart1, transmite_data, sizeof(transmite_data));

//	HAL_UART_Receive_DMA(&huart1, rxData, sizeof(rxData));
//
//	while(1) {
//		HAL_UART_Receive_DMA(&huart1, rxData, sizeof(rxData));
//	}
//
//	while(1) {
//
//		switch(rxData[6]) {
//		case 0:
//			left_duty = 0;
//			right_duty = 0;
//			control_IN_Value(1, 0, 0);
//			break;
//		case 1:
//			left_duty = 100;
//			right_duty = 100;
//			control_IN_Value(1, 0, 0);
//			break;
//		case 2:
//			left_duty = 100;
//			right_duty = 100;
//			control_IN_Value(0, 0, 0);
//			break;
//		case 4:
//			left_duty = 100;
//			right_duty = 100;
//			control_IN_Value(0, 1, 1);
//			break;
//		case 8:
//			left_duty = 100;
//			right_duty = 100;
//			control_IN_Value(0, 0, 1);
//			break;
//		}


//		// Convert the analog value of the joystick to a digital value.
//		adc_Motor_Speed();
//
//		// Determine the duty values of the motors using a speed control joystick.
//		control_speed(&left_duty, &right_duty);
//
//		// Determine the duty values of each motor using a direction control joystick.
//		control_direction(&left_duty, &right_duty);
//
		// Enter values to the input variables.
//		enter_IN_values();

		// Drive the motors by sending duty values to each motor.
//		TIM1->CCR2 = left_duty;
//		TIM3->CCR2 = right_duty;
}


// Speed Control Functions
//void control_speed(uint8_t* left_duty, uint8_t* right_duty) {
//	uint16_t adc_pwm_value = adc_value[0];
//	uint8_t command_duty = 0;
//
//	if(0 <= adc_pwm_value && adc_pwm_value <= 372) {
//		control_IN_Value(0, 0, 0);
//		command_duty = 100;
//	} else if(373 <= adc_pwm_value && adc_pwm_value <= 745) {
//		control_IN_Value(0, 0, 0);
//		command_duty = 80;
//	} else if(746 <= adc_pwm_value && adc_pwm_value <= 1118) {
//		control_IN_Value(0, 0, 0);
//		command_duty = 60;
//	} else if(1119 <= adc_pwm_value && adc_pwm_value <= 1491) {
//		control_IN_Value(0, 0, 0);
//		command_duty = 40;
//	} else if(1492 <= adc_pwm_value && adc_pwm_value <= 1864) {
//		control_IN_Value(0, 0, 0);
//		command_duty = 20;
//	} else if(1865 <= adc_pwm_value && adc_pwm_value <= 2237) {
//		stop_motor();
//		command_duty = 0;
//	} else if(2238 <= adc_pwm_value && adc_pwm_value <= 2610) {
//		control_IN_Value(1, 0, 0);
//		command_duty = 20;
//	} else if(2611 <= adc_pwm_value && adc_pwm_value <= 2983) {
//		control_IN_Value(1, 0, 0);
//		command_duty = 40;
//	} else if(2984 <= adc_pwm_value && adc_pwm_value <= 3356) {
//		control_IN_Value(1, 0, 0);
//		command_duty = 60;
//	} else if(3357 <= adc_pwm_value && adc_pwm_value <= 3729) {
//		control_IN_Value(1, 0, 0);
//		command_duty = 80;
//	} else if(3730 <= adc_pwm_value && adc_pwm_value <= 4095) {
//		control_IN_Value(1, 0, 0);
//		command_duty = 100;
//	}
//
//	*left_duty = command_duty;
//	*right_duty = command_duty;
//}

// Direction Control Function
void control_IN_Value(uint8_t forward_reverse, uint8_t left_right, uint8_t change_dir_enable) {
	if(forward_reverse) {
		// Control Left
		IN1_Value = GPIO_PIN_SET;
		IN2_Value = GPIO_PIN_RESET;
		IN3_Value = GPIO_PIN_SET;
		IN4_Value = GPIO_PIN_RESET;
	}else if(!forward_reverse) {
		IN1_Value = GPIO_PIN_RESET;
		IN2_Value = GPIO_PIN_SET;
		IN3_Value = GPIO_PIN_RESET;
		IN4_Value = GPIO_PIN_SET;
	}

	if(change_dir_enable) {
		if(left_right) {
			IN1_Value = GPIO_PIN_RESET;
			IN2_Value = GPIO_PIN_SET;
			IN3_Value = GPIO_PIN_SET;
			IN4_Value = GPIO_PIN_RESET;
		}else {
			IN1_Value = GPIO_PIN_SET;
			IN2_Value = GPIO_PIN_RESET;
			IN3_Value = GPIO_PIN_RESET;
			IN4_Value = GPIO_PIN_SET;
		}
	}
}

// Stop Motor Function
void stop_motor() {
	IN1_Value = GPIO_PIN_SET;
	IN2_Value = GPIO_PIN_SET;
	IN3_Value = GPIO_PIN_SET;
	IN4_Value = GPIO_PIN_SET;
}

// Control PWM Function
//void control_direction(uint8_t* left_duty, uint8_t* right_duty) {
//	uint16_t adc_dir_value = adc_value[1];
//
//	if (0 <= adc_dir_value && adc_dir_value <= 585) {
//		control_IN_Value(0, 1, 1);
//	} else if (586 <= adc_dir_value && adc_dir_value <= 1169) {
//		*left_duty *= 0.33;
//	} else if (1170 <= adc_dir_value && adc_dir_value <= 1754) {
//		*left_duty *= 0.66;
//	} else if (2341 <= adc_dir_value && adc_dir_value <= 2925) {
//		*right_duty *= 0.66;
//	} else if (2926 <= adc_dir_value && adc_dir_value <= 3510) {
//	    *right_duty *= 0.33;
//	} else if (3511 <= adc_dir_value && adc_dir_value <= 4095) {
//		control_IN_Value(0, 0, 1);
//	}
//}
//
//// PWM of Motor Function
//void adc_Motor_Speed() {
//	HAL_ADC_Start_DMA(&hadc1, adc_value, 2);
//	HAL_Delay(500);
//}

// Enter values to the input variables.
void enter_IN_values() {
	HAL_GPIO_WritePin(IN1_PORT, IN1_PIN, IN1_Value);
	HAL_GPIO_WritePin(IN2_PORT, IN2_PIN, IN2_Value);
	HAL_GPIO_WritePin(IN3_PORT, IN3_PIN, IN3_Value);
	HAL_GPIO_WritePin(IN4_PORT, IN4_PIN, IN4_Value);
}

// Callback function of BlueTooth
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
	HAL_UART_Receive_DMA(&huart1, rxData, sizeof(rxData));
}

