/*
 * def.h
 *
 *  Created on: Sep 13, 2024
 *      Author: OMG
 */

#ifndef COMMON_DEF_H_
#define COMMON_DEF_H_


#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

#include "main.h"


#endif /* COMMON_DEF_H_ */
